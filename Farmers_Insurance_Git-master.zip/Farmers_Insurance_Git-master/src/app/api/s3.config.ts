export const s3config = {
    accessKeyId: '', 
    secretAccessKey: '', 
    region: 'us-east-1'
}