import { Component, OnInit } from '@angular/core';
import { AppService } from './app.service';
import { SwUpdate } from '@angular/service-worker';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']

    
})
export class AppComponent implements OnInit {
  showtoast: boolean = false;
  hasConnection: boolean = true;
  constructor(private appService: AppService, private updates: SwUpdate) {
    updates.available.subscribe(event => {
      updates.activateUpdate().then(() => {
        document.location.reload(true);
      })
    })
   // updates.checkForUpdate();
    this.appService.isConnected.subscribe(isConnected => {
      if(isConnected != null){
        this.hasConnection = isConnected;
        this.showtoast = true;
        if(this.hasConnection){
          setTimeout(() => {
            this.showtoast = false;
          }, 4000);
        }
      }
    })
  }
  hideToast(data) {
    this.showtoast = false;
  }
  
  myStyle: object = {};
  myParams: object = {};
  width: number = 100;
  height: number = 100;
  ngOnInit() {

    this.myStyle = this.appService.myStyle;
    this.myParams = this.appService.myParams;
    this.width = this.appService.width;
    this.height = this.appService.height;
  }
}
