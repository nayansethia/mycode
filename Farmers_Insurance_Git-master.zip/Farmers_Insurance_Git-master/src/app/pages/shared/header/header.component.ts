import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'iedsp-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Input() title: string;
  @Input() action: string;
  @Output() actionEvent: EventEmitter<string> = new EventEmitter<string>();
  @Output() outputToParent:EventEmitter<string> = new EventEmitter<string>();
  constructor() { }

  ngOnInit() {
    // console.log('hello');
  }
  notificationToParent(){
    // this.ngOnInit();
    this.outputToParent.emit('refresh');
  }
  emitAction() {
 
    this.actionEvent.emit(this.action);
  }

}
