import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-listening',
  templateUrl: './listening.component.html',
  styleUrls: ['./listening.component.scss']
})
export class ListeningComponent implements OnInit {
  @Input('listening')listening :boolean= false;
  get changeListening() {
    return this.listening;
  }

  constructor() { }

  ngOnInit() {
    console.log(this.listening);
  }

}
