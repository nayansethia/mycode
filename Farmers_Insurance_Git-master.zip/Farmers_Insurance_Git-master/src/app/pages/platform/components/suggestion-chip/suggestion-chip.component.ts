import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'app-suggestion-chip',
  templateUrl: './suggestion-chip.component.html',
  styleUrls: ['./suggestion-chip.component.scss']
})
export class SuggestionChipComponent implements OnInit, OnChanges {
  @Input() responseCard;
  @Output('chipEvent') chipEvent = new EventEmitter<string>();
  offCanvas: boolean = false;
  currentPlanInfo: any;

  mySlideOptions = { items: 2, dots: false, nav: true };
  myCarouselOptions = { items: 1, dots: true, nav: true };
  chips: any = [];
  constructor() { }
public values;
  ngOnInit() {
    // console.log("printing response card in suggesstion chip " + JSON.stringify(this.responseCard));
    this.chips= this.responseCard;


  }

  ngOnChanges() {

  }

  chipClick(chip) {
    this.chipEvent.emit(chip);
  }


}
