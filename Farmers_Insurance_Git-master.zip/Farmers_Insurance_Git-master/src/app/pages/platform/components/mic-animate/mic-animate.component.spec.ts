import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MicAnimateComponent } from './mic-animate.component';

describe('MicAnimateComponent', () => {
  let component: MicAnimateComponent;
  let fixture: ComponentFixture<MicAnimateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MicAnimateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MicAnimateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
