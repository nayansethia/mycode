import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mic-animate',
  templateUrl: './mic-animate.component.html',
  styleUrls: ['./mic-animate.component.scss']
})
export class MicAnimateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
