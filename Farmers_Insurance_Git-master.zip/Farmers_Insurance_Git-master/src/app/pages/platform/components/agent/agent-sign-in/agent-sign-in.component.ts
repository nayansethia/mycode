import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// import { FireloginService } from '../../../services/fire-login.service';
// import { ApiService } from '../../../services/api.service';
// import { DataService } from '../../../services/data.service';
// import { HelperService } from '../../../services/helper.service';
import { ToastrService } from 'ngx-toastr';


@Component({
	selector: 'app-agent-sign-in',
	templateUrl: './agent-sign-in.component.html',
	styleUrls: ['./agent-sign-in.component.css']
})
export class AgentSignInComponent implements OnInit {
	imageSources: Array<string> = [
		'assets/images/carausal1.jpg',
		'assets/images/carausal2.jpg',
		'assets/images/carausal3.jpg'
	]
	gettingSessions: boolean = true;
	isSubmiting: boolean = false;
	password: string = '';
	username: string = '';
	selectedSession: string = '';
	sessions: Array<any> = []
	// constructor(public fireLogin:FireloginService, public helperServ: HelperService,public router:Router,public data: DataService,public apiService:ApiService,private toastr: ToastrService) { 
	// 	this.helperServ.sendUrl('signin')
	// }

	constructor(public router: Router) {
	}

	ngOnInit() {
		document.title = 'Agent || Quantiphi Contact Center AI';
		let name = ["John", "Mike"];
		// this.apiService.getAvailableSessions()
		// .subscribe(value => {
		// 	console.log(value);
		// 	this.sessions = value.data.sessions.reverse().slice(0,2).map( (s,i) => {
		// 		let tempName = s.name.split('/');
		// 		return {
		// 			name:name[i],
		// 			value:s.name
		// 		}
		// 	})
		// 	this.selectedSession = this.sessions[0].value;
		// 	this.gettingSessions = false;
		// })
	}

	public submit() {
		this.isSubmiting = false;
		this.router.navigate(['app/agent/sessions'])
	}

	checkForSubmit = (e) => {
		if (e.keyCode == 13 && this.username && this.password) {
			this.submit();
		}
	}


	// public submit(){
	// 	console.log("helllll")
	// 	if(!this.username || !this.password){
	// 		return
	// 	}
	// 	this.isSubmiting = true;
	// 	this.fireLogin.login(this.username,this.password)
	// 	.then(value => {
	// 		if(this.username === "agent@quantiphi.com" || this.username === "demo@quantiphi.com"){
	// 			localStorage.setItem('email', value.user.email);
	// 			this.data.setUsername(value.user.email);
	// 			this.router.navigate(['/agent/sessions']);
	// 		}else{
	// 			this.toastr.error('Username/password Incorrect','',{timeOut:1000*60});
	// 			this.isSubmiting = false
	// 		}
	// 	}).catch(err => {
	// 		this.toastr.error('Username/password Incorrect','',{timeOut:1000*60});
	// 		console.log('Something went wrong:', err.message);
	// 		this.isSubmiting = false;
	// 	});	
	// }


}
