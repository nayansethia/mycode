import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ApiService } from '../../../services/http.service';



@Component({
	selector: 'app-agent-dashboard',
	templateUrl: './agent-dashboard.component.html',
	styleUrls: ['./agent-dashboard.component.scss']
})
export class AgentDashboardComponent {
	loader: boolean = true;

	previousChat = [];
	chatHistory = [];
	userChatRoom = localStorage.getItem("sessionId");

	constructor(public router: Router, private toastr: ToastrService, private http: ApiService) {

	}

	ngOnInit() {
		this.http.getPreviousChat(this.userChatRoom).subscribe((res: any) => {
			console.log("previous chat history");
		});
		this.http.getChatHistory(this.userChatRoom).subscribe((res: any) => {
			this.loader = false;
			console.log("full chat history");
		})

	}
}
