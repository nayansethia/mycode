import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentSessionScreenComponent } from './agent-session-screen.component';

describe('AgentSessionScreenComponent', () => {
  let component: AgentSessionScreenComponent;
  let fixture: ComponentFixture<AgentSessionScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentSessionScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentSessionScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
