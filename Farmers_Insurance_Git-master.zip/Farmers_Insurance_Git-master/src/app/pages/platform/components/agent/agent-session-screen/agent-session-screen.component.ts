import { Component, OnInit, OnDestroy } from '@angular/core';
// import { ApiService } from '../../../services/api.service';
// import { DataService } from '../../../services/data.service';
// import { SocketService } from '../../../services/socket.service';
// import { HelperService } from '../../../services/helper.service';
// import { NotificationService } from '../../../services/notification.service';
// import { AgentSessionService } from '../../../services/agent-session.service';


import { Router } from '@angular/router';


@Component({
	selector: 'app-agent-session-screen',
	templateUrl: './agent-session-screen.component.html',
	styleUrls: ['./agent-session-screen.component.scss']
})
export class AgentSessionScreenComponent {
	loader: boolean;
	agents: any[] = [];
	liveAgentNumber: number[] = [];
	liveAgentMail: string[] = [];
	liveAgentMode: string;
	p: number = 1;
	isSessions: boolean;
	// sessionList: any;
	updateSessionList: any;

	sessionList = [
		{
			"id": 'conversationid1',
			"STATUS": 1,
			"startTime": '12:12'
		}
		// {
		// 	"id": 'conversationid2',
		// 	"status": 4,
		// 	"startTime": '12:12'
		// }
	]


	constructor(public router: Router) {

	}

	ngOnInit() {
		this.detectSession();
		this.loader = true;

	}
	detectSession() {

		console.log("detecting session");

	}
	statusMap(status) {
		switch (status) {
			case "1": return "Talking with Bot";
			case "2": return "Live Agent Required";
			case "3": return "Conversation completed";
			case "4": return "Join On Call";
			case "5": return "Join On Video Call";
			case null: return "Telephonic";
		}
	}

	// ngOnInit() {
	// 	  this.notify.checkForPermissions();	
	// 	  this.socketService.initSocket();
	// 	  this.detectSession();
	// 	  if(localStorage.getItem('email') === null || localStorage.getItem('email') === undefined) {
	// 			this.router.navigate(['/agent']);
	// 	  }
	// 	// if (!this.data.getUsername()) {
	// 	// 	this.router.navigate(['/agent']);
	// 	// }
	// 	// this.detectSession();
	// 	this.loader = true;
	// 	this.sessionList = [];
	// 	this.getAgents();
	// 	this.apiService.getAvailableSessions().subscribe(
	// 		res=>{
	// 			console.log(res);
	// 			this.sessionList = res.data.conversations.sort(this.sortByDate("startTime") );


	// 			// this.sessionList = this.sessionList.filter( session => session.STATUS !== null);
	// 			// this.sessionList = this.sessionList.filter( session => ((new Date()).getTime() - new Date(session.openTime).getTime()) <= 20*60*1000)
	// 			this.sessionList.map(session =>{
	// 				if(((new Date()).getTime() - new Date(session.startTime).getTime()) > 20*60*1000){
	// 					session.STATUS = '3'
	// 				}
	// 			})
	// 			if(this.sessionList.length > 8){
	// 				this.isSessions = true;
	// 			  }else{
	// 				this.isSessions = false;
	// 			  }
	// 			this.sessionList.forEach((s,i) =>{
	// 					s['id'] = i+1;
	// 			});
	// 			console.log(this.sessionList);
	// 			this.loader = false;
	// 		},
	// 		err=>{
	// 			console.log(err)
	// 		}
	// 	)			
	// 	}

	// 	public sortByDate(prop){
	// 		return function(a,b){
	// 			return (new Date(b[prop]).getTime() - new Date(a[prop]).getTime());

	// 		}
	// 	}

	// 	ngOnChanges(): void {
	// 		//Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
	// 		//Add '${implements OnChanges}' to the class.

	// 	}
	// public joinSession(session){
	// 	console.log(session);
	// 	this.loader= true;
	// 	if(session.STATUS == null){
	// 		this.liveAgentMode = "telephony";
	// 	}
	// 	else{
	// 		this.liveAgentMode = "chat";

	// 	}
	// 	this.router.navigate(['/agent/dashboard',session.name,this.liveAgentMode]);
	// }

	// detectSession(){

	// 	this.socketService.onEvent("newSession")
	// 		.subscribe((message) => {

	// 		  console.log(message);

	// 		  console.log(message.name);

	// 		  var name=this.sessionList.filter(session => session.name == message.name);
	// 		  if(name.length == 0){
	// 			  console.log('it is not present');

	// 			//   let len = Object.keys(this.sessionList).length;
	// 			console.log("status type "+typeof(message.STATUS));
	// 				message.id = 1;
	// 				message.STATUS = ''+message.STATUS;
	// 			  this.sessionList.forEach((s,i) =>{
	// 				s['id'] = s['id']+1;
	// 			});
	// 			  message.startTime = new Date(); 
	// 			  this.sessionList.push(message);
	// 		  }
	// 		  else if(message.STATUS == 2){
	// 			console.log(' present');
	// 			let title =" Live agent required";
	// 			let body="checkout the session screen";
	// 			let data={
	// 				name:message.name,
	// 				liveAgentMode: "chat"
	// 			}
	// 			let options ={
	// 				body:body,
	// 				icon:'../../../../assets/images/avatar.png'
	// 			}
	// 			this.notify.notifyMe(title,options,data);

	// 			}
	// 			else if(message.STATUS == 4){
	// 				console.log(' present');
	// 				let title =" Live agent required On Call";
	// 				let body="checkout the session screen";
	// 				let data={
	// 					name:message.name,
	// 					liveAgentMode: "call"
	// 				}
	// 				let options ={
	// 					body:body,
	// 					icon:'../../../../assets/images/avatar.png'
	// 				}
	// 				this.notify.notifyMe(title,options,data);

	// 				}
	// 			else if(message.STATUS == 5){
	// 				console.log(' present');
	// 				let title =" Live agent required On Video Call";
	// 				let body="checkout the session screen";
	// 				let data={
	// 					name:message.name,
	// 					liveAgentMode: "call"
	// 				}
	// 				let options ={
	// 					body:body,
	// 					icon:'../../../../assets/images/avatar.png'
	// 				}
	// 				this.notify.notifyMe(title,options,data);

	// 				}

	// 		this.sessionList.forEach((s,i) =>{

	// 			if(s.name === message.name){
	// 				console.log('found')
	// 				s['STATUS']=""+message.STATUS;
	// 			}
	// 		})
	// 		if(this.sessionList.length > 8){
	// 			this.isSessions = true;
	// 		  }else{
	// 			this.isSessions = false;
	// 		  }
	// 		  this.sessionList = this.sessionList.sort(this.sortByDate("startTime"));
	// 		});
	// }

	// statusMap(status) {
	// 	switch(status) {
	// 		case "1": return "Talking with Bot";
	// 		case "2": return "Live Agent Required";
	// 		case "3": return "Conversation completed";
	// 		case "4": return "Join On Call";
	// 		case "5": return "Join On Video Call";
	// 		case null: return "Telephonic";
	// 	}
	// }

	// startCall(session,i) {
	// 	let obj = {
	// 		session: session.name,
	// 		agentNumber: this.liveAgentNumber[i]['id'] || this.liveAgentNumber[i]['label']
	// 	}
	// 	this.agentSessisnServ.getUser(obj).subscribe(res=>{
	// 		console.log(res);
	// 		this.sessionList[i].STATUS = 3;
	// 		this.statusMap(this.sessionList[i].STATUS)
	// 		this.liveAgentNumber[i] = undefined;
	// 		this.socketService.send({
	// 			id:'joinCall',
	// 			sessionId:session.name,
	// 		});
	// 	},
	// 	err=>{
	// 		console.log(err)
	// 	})
	// }

	// startVideoCall(session,i) {
	// 	console.log(session,this.liveAgentMail[i]);
	// 	let obj = {
	// 		session: session.name,
	// 		liveAgentEmail: this.liveAgentMail[i]
	// 	}
	// 	this.agentSessisnServ.startVideoCall(obj).subscribe(res=>{
	// 		console.log(res);
	// 		this.sessionList[i].STATUS = 3;
	// 		this.liveAgentMail[i] = undefined;
	// 		this.socketService.send({
	// 			id:'joinVideoCall',
	// 			sessionId:session.name,
	// 		})		},
	// 	err=>{
	// 		console.log(err)
	// 	})
	// }

	// ngOnDestroy(){
	// 	this.loader =false;
	// }
	// getAgents() {
	// 	this.agentSessisnServ.getAgents().subscribe(
	// 		res=>{
	// 			console.log(res);
	// 			res['data'].forEach(element=>{
	// 				this.agents.push({
	// 					id:element.number,
	// 					label: element.name
	// 				});
	// 				// this.agents.push(element.name)
	// 			});
	// 			console.log(this.agents);
	// 		},
	// 		err=>{
	// 			console.log(err)
	// 		}
	// 	)
	// }
}
