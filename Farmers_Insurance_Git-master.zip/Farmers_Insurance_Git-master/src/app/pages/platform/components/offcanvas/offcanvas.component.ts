import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
	trigger,
	state,
	style,
	animate,
	transition,
	// ...
} from '@angular/animations';
@Component({
  selector: 'app-offcanvas',
  templateUrl: './offcanvas.component.html',
  styleUrls: ['./offcanvas.component.scss'],
  animations: [
		trigger('toggle-canvas', [
			state('showCanvas', style({
				right: 0,
				top: 0
			})),
			state('hideCanvas', style({
				right: "-400px"
			})),
			transition('* => *', [
				animate('0.5s')
			]),
		])
	]
})
export class OffcanvasComponent implements OnInit {

  constructor() { }

  @Input() isActive;
  @Output() isActiveChange = new EventEmitter();
  // @Input() currentPlanInfo;
  ngOnInit() {
    console.log(this.isActive);
  }

  ngOnChanges(): void {
    //Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    //Add '${implements OnChanges}' to the class.
    console.log(this.isActive);
  }
  close(){
    this.isActive = false;
    this.isActiveChange.emit(this.isActive);
  }
}
