import { Component, OnInit, Input, OnChanges, NgZone, Output, EventEmitter } from '@angular/core';
// import { SpeechSynthesisService } from '../../services/speech-synthesis.service';
import { SpeechEventService } from '../../services/speech-event';
import { getViewData } from '@angular/core/src/render3/instructions';


@Component({
  selector: 'app-speech-synthesis',
  templateUrl: './speech-synthesis.component.html',
  styleUrls: ['./speech-synthesis.component.scss']
})
export class SpeechSynthesisComponent implements OnInit, OnChanges {
  @Input('audioString') audioString: any;
  @Input('userType') userType: any;

  constructor(private speechEventService: SpeechEventService, public ngZoneService: NgZone) {
  }

  color = 'accent';
  checked = false;
  disabled = false;

  voices = [];
  languages: any;
  language: any;
  volume: number = 0.4;
  pitch: number = 0.0;
  rate: number = 1.0;
  audioProfiles: string[] = ['wearable-class-device', 'handset-class-device', 'headphone-class-device', 'small-bluetooth-speaker-class-device', 'medium-bluetooth-speaker-class-device', 'large-home-entertainment-class-device', 'large-automotive-class-device', 'telephony-class-application']

  progress_index = 0;
  speakingVoice;
  langu;

  synthVoice() {

    const awaitVoices = new Promise(resolve =>
      window.speechSynthesis.onvoiceschanged = resolve)
      .then(() => {
        var self = this;
        const synth = window.speechSynthesis;
        this.languages = [];
        this.voices = synth.getVoices();
        this.speakingVoice = this.voices[4];
        // this.language = this.voices[4].name;
        this.voices.forEach(element => {
          // this.languages.push(element.name);
          this.languages.push(element.name.replace(/Google|Microsoft/gi, ''));
        })
      }).then(() => {
        console.log("all languages " + JSON.stringify(this.languages));
      });
    this.ngZoneService.run(this.changeUI);
  }

  ngOnInit() {
    this.synthVoice();
    this.ngZoneService.run(this.changeUI);

  }

  k = ""
  ngOnChanges() {
    this.speechEventService.set(true);

    if (this.audioString == undefined) {
      this.ngZoneService.run(this.changeUI);

    }
    else {
      if (this.k == "mutexyz") {
        speechSynthesis.cancel();
        this.speechEventService.set(true);
        console.log("audiostring printing " + this.audioString.value)
        var synt = new SpeechSynthesisUtterance(this.audioString.value);
        synt.text = '';
        synt.volume = this.volume;
        synt.pitch = this.pitch;
        synt.rate = this.rate;
        synt.voice = this.speakingVoice;
        synt.onstart = (event) => {
          this.speechEventService.set(true);
        }
        synt.onend = (event) => {
          console.log("speaking " + speechSynthesis.speaking);
          console.log("pending " + speechSynthesis.pending);

          if (speechSynthesis.pending == false && speechSynthesis.speaking == false) {
            this.speechEventService.set(false);
          } else {
            this.speechEventService.set(false);


          }
        }
        this.ngZoneService.run(this.changeUI);

        speechSynthesis.speak(synt);

      }
      // else if (this.audioString.value == "stopthelistener") {
      //   this.speechEventService.set(true);
      //   speechSynthesis.cancel();
      // }
      else if (this.audioString.value == "") {
        this.speechEventService.set(true);
        speechSynthesis.cancel();
      }
      else {
        this.speechEventService.set(true);
        console.log("audiostring printing " + this.audioString.value)
        var synt = new SpeechSynthesisUtterance(this.audioString.value);
        synt.text = this.audioString.value;
        synt.volume = this.volume;
        synt.pitch = this.pitch;
        synt.rate = this.rate;
        synt.voice = this.speakingVoice;

        console.log("prininting the voice selected " + this.speakingVoice);

        synt.onstart = (event) => {
          this.speechEventService.set(true);
        }
        synt.onend = (event) => {
          console.log("speaking " + speechSynthesis.speaking);
          console.log("pending " + speechSynthesis.pending);

          if (speechSynthesis.pending == false && speechSynthesis.speaking == false) {
            this.speechEventService.set(false);
          } else {
            this.speechEventService.set(false);


          }
        }
        this.ngZoneService.run(this.changeUI);

        speechSynthesis.speak(synt);

      }





    }



  }
  languageChange(language) {
    for (let i = 0; i < this.voices.length; i++) {

      if (this.voices[i].name.replace(/Google|Microsoft/gi, '') === language) {
        this.speakingVoice = this.voices[i];
        console.log("printing the lanuage speaking " + this.voices[i]);
      }

    }
    this.ngZoneService.run(this.changeUI);

  }
  volumeSlide(e) {
    this.volume = e.value;
    console.log("printing the volume change " + this.volume);

  }
  rateSlide(e) {
    this.rate = e.value;
  }

  pitchSlide(e) {
    this.pitch = e.value;
  }

  mutetoggle(value) {
    this.checked = !value;
    if (this.checked == true) {
      this.volume = 0;
      this.k = "mutexyz";
      this.ngOnChanges();
    } else {
      this.volume = 0.4;
      this.k = "";
      // this.audioString.value = this.audioString.value;
      this.ngOnChanges();

    }

    console.log("checking mute value " + !value);
  }

  changeUI() {
    console.log("change UI");
  }
}
