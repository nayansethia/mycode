import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss']
})
export class CarouselComponent implements OnInit {

  constructor() { }

  isActive = true;
  @Input() mySlideOptions;
  @Input() planinfo;
  @Input() myCarouselOptions;
  // @Output() showOffcanvas = new EventEmitter();
  @Output() currentPlan = new EventEmitter();
  ngOnInit() {
  }
  toggle(plan){
    // this.isActive = !this.isActive;
    this.isActive = true;
    // this.showOffcanvas.emit(this.isActive);
    this.currentPlan.emit(plan)
  }

}
