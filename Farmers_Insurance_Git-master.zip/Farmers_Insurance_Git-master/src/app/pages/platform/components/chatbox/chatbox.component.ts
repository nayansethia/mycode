import { Component, OnInit, Input, Output, EventEmitter, OnChanges, NgZone, IterableDiffers, KeyValueChangeRecord, IterableChangeRecord } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription, config } from 'rxjs';
import { UserChatConfig, AgentChatConfig } from '../../config/app.config';
import { ToastrService, ToastrConfig } from 'ngx-toastr';
import { SpeechEventService } from '../../services/speech-event';
// import { PlatformService } from '../../services/platform.service';
import { SpeechSynthesisComponent } from '../speech-synthesis/speech-synthesis.component';
import { MikeComponent } from '../mike/mike.component';

import { SocketService } from '../../services/socket.service';
import { HelperService } from '../../services/helper.service';


import * as AWS from 'aws-sdk';
import Speech from 'speak-tts';
import { exists } from 'fs';

@Component({
	selector: 'app-chatbox',
	templateUrl: './chatbox.component.html',
	styleUrls: ['./chatbox.component.css'],
	providers: [SpeechSynthesisComponent, MikeComponent]
})
export class ChatboxComponent implements OnInit, OnChanges {

	typing: boolean = false;
	test: boolean = true;
	scrollMe: any;
	feedBackSumbitted: boolean[] = [];
	userconfig = new UserChatConfig();
	agentConfig = new AgentChatConfig();
	subscription: Subscription;
	offCanvas: boolean;
	isBlurred: boolean = false;
	detectSSN: boolean = false;
	preventUserRequest: boolean = false;
	trackIntentForToastr: boolean = false;
	chatNewParams = {};
	detectAccountNumber: boolean = true;
	location: any;
	address: any;
	submitting: boolean = false;
	@Input() me: string;
	@Input() status: string;
	@Input('previousMessages') previousMessages: Array<any>;
	@Input() isPolling: boolean = false;
	@Output() eventNotify = new EventEmitter();
	@Output() chatParams = new EventEmitter<object>();
	@Output() audioOutPut = new EventEmitter<any>();
	@Output() chatInterpretation = new EventEmitter<any>();


	@Input() config;


	lastIntent: string;
	// ResponseCard = [];
	urlPresent: boolean = false;
	disableChat: boolean = true;
	feedback: any;
	sendListening: boolean = false;
	mikeStart: boolean = false;
	textMessage: string;
	agentName: string = 'Virtual Agent';
	agentRole: string = 'Virtual Agent';
	images: object = {
		'END_USER': 'assets/images/john.jpg',
		'AUTOMATED_AGENT': 'assets/images/avatar.png',
		'AGENT': 'assets/images/amy.jpg'
	};
	conversations: Array<object> = [];
	messages: Array<object> = [];
	public speech = new Speech();


	//refrence for the chatinterpretation
	public IntentName;
	public SlotName;
	public SlotValue;

	public inputDisable = false;

	public iterableDiffer;


	constructor(private _iterableDiffers: IterableDiffers, public helperServ: HelperService, private toastr: ToastrService, private ngzone: NgZone, public router: Router, private speechEventService: SpeechEventService, public speechSynthesisComponent: SpeechSynthesisComponent, public mikeComponent: MikeComponent, public socketService: SocketService) {
		this.iterableDiffer = this._iterableDiffers.find([]).create(null);

	}
	public lexruntime;
	public lexUserId;
	public sessionAttributes;

	ngDoCheck() {
		let changes = this.iterableDiffer.diff(this.messages);
		if (changes) {
			changes.forEachAddedItem((record: IterableChangeRecord<any>) => {
				this.socketService.send({ "id": 'wholeSessionChat', "sessionId": localStorage.getItem("sessionId"), "data": this.messages[record.currentIndex] });
			});
		}
	}

	ngOnInit() {

		this.socketService.initSocket();

		// this.socketService.send({
		// 	id: 'userMessage',
		// 	sessionId: "testsessionid",
		// 	message: "Hi",
		// 	participantName: "testparticipate"
		// });
		this.test = true;
		this.offCanvas = false;
		AWS.config.region = 'us-east-1'; // Region
		AWS.config.credentials = new AWS.CognitoIdentityCredentials({
			IdentityPoolId: 'us-east-1:9904ef32-f8f7-45fe-b1cb-10120b848708',
		});
		this.lexruntime = new AWS.LexRuntime();
		this.lexUserId = 'chatbot-demo' + Date.now();
		this.sessionAttributes = {};
		if (localStorage.getItem("previousConv") == 'yes') {
			this.prevConv = true;
		}
		else {
			this.pushChat();

		}
	}
	public prevConv = false;

	ngOnChanges() {
		console.log(this.status);
		this.ngzone.run(this.changeUI);
		if (this.me === 'AGENT') {
			this.subscription = this.helperServ.$agentchatConfig.subscribe(
				res => {
					console.log(res);
					console.log(this.status);
					this.agentConfig = res;
				},
				err => {
					console.log(err)
				}
			)
		}
		if (this.me === 'END_USER') {
			// if(this.userconfig.speechSynthesis && this.data.getSessionData()) {
			// 	this.audioOutPut.emit({ssml:true, value:this.messages[0]['ssml']});
			// }
			this.subscription = this.helperServ.$chatConfig.subscribe(
				res => {
					console.log(res);
					this.userconfig = res;
				},
				err => {
					console.log(err)
				}
			)
		}
		if (this.previousMessages) {
			this.messages = this.previousMessages;
		}
	}

	// private initIoConnection(): void {
	// 	let sessionData = this.data.getSessionData();
	// 	if (sessionData) {
	// 		this.socketService.initSocket();
	// 		if (this.me === "END_USER") {
	// 			this.socketService.send({ "id": 'createRoom', "sessionId": sessionData.name });
	// 			this.socketService.onEvent("agentMessage")
	// 				.subscribe((message) => {
	// 					this.onAgentMesage(message);
	// 				});
	// 			this.socketService.onEvent("agentJoin")
	// 				.subscribe((message) => {
	// 					console.log(message);
	// 					this.onAgentJoin(message);
	// 				});
	// 		} else {
	// 			this.socketService.send({ "id": 'agentJoinRoom', "sessionId": sessionData.name });
	// 			this.socketService.onEvent("userMessage")
	// 				.subscribe((message) => {
	// 					this.onUserMesage(message);
	// 				});

	// 		}
	// 		this.socketService.onEvent("botMessage")
	// 			.subscribe((message) => {
	// 				this.onBotMesage(message);
	// 			});

	// 	}
	// }


	talktolex(e?) {
		var self = this;
		if (this.textMessage == "" || this.textMessage == undefined || typeof (this.textMessage) == "undefined") {
			this.textMessage = "hi";
		} else {
			this.messages.push({
				type: 'conversation',
				message: this.textMessage,
				timestamp: new Date(),
				user: 'END_USER',
				isFaded: false,
				hasReponsecard: "false",

			});

			if (this.textMessage.toLowerCase() == "car insurance") {
				setTimeout(() => {
					self.audioOutPut.emit({ value: '' });

				}, 100);

				self.messages.push({
					type: 'conversation',
					message: 'Sure. I will need some details from you to proceed further.',
					timestamp: new Date(),
					user: 'AUTOMATED_AGENT',
					isFaded: false,
					hasReponsecard: "false",

				});

				setTimeout(() => {

					self.audioOutPut.emit({ value: 'Sure. I will need some details from you to proceed further.' });


				}, 120);
			}
		}

		this.ngzone.run(this.changeUI);
		this.setTyping(false);

		var paramss = {
			botAlias: '$LATEST',
			botName: 'InsuranceBot',
			//  botName: 'AutoClaim',

			inputText: this.textMessage,
			userId: this.lexUserId,
			sessionAttributes: this.sessionAttributes
		};
		this.textMessage = "";

		//   self.showRequest(this.viewInput);
		this.lexruntime.postText(paramss, function (err, data) {

			var count = 0;

			if (err) {
				console.log(err, err.stack);
			}
			if (data) {

				console.log("printing intent name: " + data.intentName);
				console.log("printng the incoming data all " + data.dialogState);
				if (data.intentName == null) {
					self.messages.push({
						type: 'conversation',
						message: "please choose from the options",
						timestamp: new Date(),
						user: 'AUTOMATED_AGENT',
						isFaded: false,
					});

					setTimeout(() => {
						self.audioOutPut.emit({ value: 'please choose from the options' });


					}, 100);
				} else if (data.intentName == "Greeting") {
					console.log("intent name is greetings");
					self.IntentName = "";


				} else {

					self.IntentName = data.intentName;
					console.log("printing the type of slot" + typeof (data.slots));
					if (typeof (data.slots) == undefined) {
						console.log("undefined inside");

					} else {
						var slotsArray = [];
						Object.keys(data.slots).forEach((e) => {
							console.log(`key=${e}  value=${data.slots[e]}`)
							if (data.slots[e] == null) {
								// console.log("null");
							} else {
								slotsArray.push({ name: e, value: data.slots[e] });
								self.chatInterpretation.emit(slotsArray);
							}
						});

						console.log("chatinterpretation slots printing" + JSON.stringify(slotsArray));



					}
				}

				// capture the sessionAttributes for the next cycle
				self.sessionAttributes = data.sessionAttributes;
				console.log("printing the response overalldata" + data.message);


				if (data.intentName == null) {

				} else {
					var botMessage = data.message;
					self.messages.push({
						type: 'conversation',
						message: data.message,
						timestamp: new Date(),
						user: 'AUTOMATED_AGENT',
						isFaded: false,
					});

					setTimeout(() => {
						self.audioOutPut.emit({ value: data.message });


					}, 100);

				}
				self.ngzone.run(self.changeUI);

			}

			var title;
			var subtitle;
			var buttons;


			if (typeof (data.responseCard) == "undefined") {
				console.log("printing if data.responseCard type is undefined" + data.responseCard);
			} else {
				console.log("type of response card" + typeof (data.responseCard));
				var cardData = data.responseCard.genericAttachments;
				console.log("printing cardData " + JSON.stringify(cardData));
				console.log("printing the length of card data " + cardData.length);

				for (let i = 0; i < cardData.length; i++) {
					title = cardData[i].title;
					subtitle = cardData[i].subTitle;
					buttons = cardData[i].buttons;
					var buttonsChip = "";

					for (let j = 0; j < buttons.length; j++) {
						buttonsChip = buttonsChip + buttons[j].text + ",";
					}

					self.messages.push({
						type: 'conversation',
						message: title + subtitle,
						timestamp: new Date(),
						user: 'AUTOMATED_AGENT',
						isFaded: false,
						hasReponsecard: "True",
						responseCard: buttons

					});

					setTimeout(() => {
						self.audioOutPut.emit({ value: title + subtitle + buttonsChip });
					}, 120);

				}
			}
			if (data.dialogState == "Fulfilled" && data.intentName == self.IntentName && data.intentName != 'ConnectAgent') {
				self.messages.push({
					type: 'notification',
					message: "Conversation End",
					timestamp: new Date()
				});
				self.textMessage = null;
				setTimeout(() => {
					self.mikeComponent.speechRecognitionEnabled = true;
				}, 5000);
				self.test = false;
				self.inputDisable = true;
				console.log("notification message pushed");
				console.log("printing the message array" + JSON.stringify(self.messages));
			}

		});


		return false;
	}
	talktoagent() {
		console.log("talk to agent executed");
	}
	agentJoin = false;
	pushChat(e?) {

		var self = this;
		if (typeof (e) == "undefined") {
			console.log("push chat is undefined");
		} else {
			e.preventDefault();
		}
		this.audioOutPut.emit({ value: "" });

		if (this.agentJoin == true) {
			this.talktoagent();
		} else {
			this.talktolex();
		}


	}

	startNewSession() {
		this.inputDisable = false;
		this.refreshChat();
	}


	onBotMesage(data) {
	}

	changeUI() {
		console.log("Change UI");

	}
	onAgentMesage(data) {

	}

	onAgentJoin(data) {
		return true;
	}
	onUserMesage(data) {

	}

	onNewMessage(messages) {

	}

	checkForSubmit = (e) => {
		if (e.keyCode == 13) {
			if (this.textMessage.length > 0)
				this.pushChat();
		}
	}


	getAudio(event) {

		var self = this;
		if (event == "") {
		} else {
			console.log('Sound', event);

			this.textMessage = event;

			if (this.textMessage == "") {
				this.toastr.error("Sorry Could not Hear You !!")
			} else {
				this.pushChat();
				this.textMessage = "";


			}



		}


	}

	mikeOn(event) {
		this.mikeStart = event;

	}

	emitsendListening(flag) {

		this.sendListening = flag;



	}

	getFeedback(event) {
		console.log(event, this.lastIntent);
		this.feedback = event;
		let storeFeedbackobj = {
			"comments": event.feedbackOptions,
			"timestamp": new Date().getTime(),
			"isPositive": event.positive
		}
		this.messages[this.messages.length - 1]['feedback'] = event;

	}
	setTyping(flag: boolean) {
		this.typing = flag;

	}

	sendDisabled(i) {
		if (i !== this.messages.length - 1) {
			return true;
		} else if (i === this.messages.length - 1) {
			if (this.feedBackSumbitted[i]) {
				return true;
			} else {
				return false;
			}
		}
	}

	chipClick(event) {
		this.textMessage = event.text;
		if (event.text == 'Chat') {
			this.messages.push({
				type: 'conversation',
				message: this.textMessage,
				timestamp: new Date(),
				user: 'END_USER',
				isFaded: false,
				hasReponsecard: "false",

			});
			this.textMessage = null;
			this.inputDisable = true;
			this.test = false;
			this.typing = true;

			this.messages.push({
				type: 'conversation',
				message: "Please wait while we connect you to a live agent",
				timestamp: new Date(),
				user: 'AUTOMATED_AGENT',
				isFaded: false,
				hasReponsecard: "false",

			});
		} else {
			this.pushChat();

		}
	}

	toggleOffcanvas() {

		let a = this.toastr.info('A certificate of deposit is a time deposit, a financial product commonly sold in the United States and elsewhere by banks, thrift institutions, and credit unions. CDs are similar to savings accounts in that they are insured "money in the bank" and thus virtually risk free.More Details', 'Certoificate of Deposit', { disableTimeOut: true })
		this.isBlurred = true;
		a.onTap.subscribe((event) => {
			this.isBlurred = false;
		})
	}

	print(me, agentConfig, userconfig) {
		console.log(me, agentConfig, userconfig)
	}
	check() {
		console.log(this.userconfig);
		console.log(this.config);
	}

	openModal() {
		document.getElementById('map-Modal').style.display = 'block';
	}

	closeModal() {
		document.getElementById('map-Modal').style.display = 'none';
	}
	submitLocation(event) {
		console.log(event);
		this.closeModal();
		this.textMessage = event;
		// this.sendMessage();
	}

	refreshChat() {

		console.log("refresh chat got clicked");
		document.getElementById("spinme").classList.add("fa-spin");
		setTimeout(() => {
			document.getElementById("spinme").classList.remove("fa-spin");
		}, 2000);
		this.messages.length = 0;
		this.ngOnInit();


	}

}
