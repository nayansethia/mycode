import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Pipe({ name: 'keepHtml', pure: false })
export class Domsanitizer implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {
  }

    transform(value: string, args: string[]): any {
        return value.replace(/(?:\r\n|\r|\\n)/g, '<br />');
    
  }
}