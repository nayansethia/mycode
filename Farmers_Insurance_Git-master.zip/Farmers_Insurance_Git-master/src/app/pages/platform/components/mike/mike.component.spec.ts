import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MikeComponent } from './mike.component';

describe('MikeComponent', () => {
  let component: MikeComponent;
  let fixture: ComponentFixture<MikeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MikeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MikeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
