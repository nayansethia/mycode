import { Component, OnInit, NgZone, Input, EventEmitter, Output } from '@angular/core';
import { SpeechEventService } from '../../services/speech-event';

interface IWindow extends Window {
  webkitSpeechRecognition: any;
  SpeechRecognition: any;
  mozSpeechRecognition: any;
  oSpeechRecognition: any;
  SpeechGrammarList: any;
  webkitSpeechGrammarList: any;
  mozSpeechGrammarList: any;
  oSpeechGrammarList: any;
}
@Component({
  selector: 'app-mike',
  templateUrl: './mike.component.html',
  styleUrls: ['./mike.component.scss']
})
export class MikeComponent implements OnInit {
  startListening: boolean;
  @Output('enableSpeech') enableSpeech = new EventEmitter();
  @Output('submit') submit = new EventEmitter();
  speech = new SpeechSynthesisUtterance();
  listening: boolean = false;
  sendListening:boolean = false
  @Output('emitsendListening') emitsendListening = new EventEmitter();
  interimMsg: string;
  speechRecognition: any;
  speechRecognitionEnabled: boolean = false;
  showInterimResults: any = '';
  botPause:boolean;
  constructor( public ngZoneService: NgZone, private speechEventService:SpeechEventService) { }

  ngOnInit() {
    this.botPause = false;
    this.speechEventService.change.subscribe(isBotTalking => {
      if(this.speechRecognitionEnabled && isBotTalking){
        console.log("stopped");
        this.speechRecognition.stop();
        this.speechRecognition.abort();
        this.botPause = true;
      }else if(!isBotTalking && this.botPause){
        this.botPause = false;
        if(this.speechRecognitionEnabled){
          this.speechRecognition.start();
        }
      }
    });
  }

  toggleSpeechRecognition() {
    console.log("end listening", this.speechRecognitionEnabled);
    this.speechRecognitionEnabled = !this.speechRecognitionEnabled;
    this.enableSpeech.emit(this.speechRecognitionEnabled);
    if (('webkitSpeechRecognition' in window) || ('mozSpeechRecognition' in window)
      || ('oSpeechRecognition' in window) || ('oSpeechRecognition' in window)) {
      if (this.speechRecognitionEnabled) {
        let lastConfidence = 0;
        const { webkitSpeechRecognition }: IWindow = <IWindow>window;
        const { SpeechRecognition }: IWindow = <IWindow>window;
        const { mozSpeechRecognition }: IWindow = <IWindow>window;
        const { oSpeechRecognition }: IWindow = <IWindow>window;

        const { webkitSpeechGrammarList }: IWindow = <IWindow>window;
        const { SpeechGrammarList }: IWindow = <IWindow>window;
        const { mozSpeechGrammarList }: IWindow = <IWindow>window;
        const { oSpeechGrammarList }: IWindow = <IWindow>window;

        if (!!webkitSpeechRecognition) {
          this.speechRecognition = new webkitSpeechRecognition();
          var speechRecognitionList = new webkitSpeechGrammarList();
        }
        else if (!!SpeechRecognition) {
          this.speechRecognition = new SpeechRecognition();
          var speechRecognitionList = new SpeechGrammarList();
        }
        else if (!!mozSpeechRecognition) {
          this.speechRecognition = new mozSpeechRecognition();
          var speechRecognitionList = new mozSpeechGrammarList();
        }
        else if (!!oSpeechRecognition) {
          this.speechRecognition = new oSpeechRecognition();
          var speechRecognitionList = new oSpeechGrammarList();
        }

        if (!this.speechRecognition) {
          return;
        }

        var names = ['Hi','Hello','Thats true', 'Yes', 'No', 'go ahead','I am','I','do','Nursing','Bachelors','Masters'];
        var grammar = '#JSGF V1.0; grammar colors; public <color> = ' + names.join(' | ') + ' ;';
        //this.speechRecognition = new webkitSpeechRecognition();
        //this.speechRecognition.continuous = true;
        speechRecognitionList.addFromString(grammar, 1);
        this.speechRecognition.interimResults = true;
        this.speechRecognition.continuous = true;
        this.speechRecognition.lang = 'en-us';
        this.speechRecognition.maxAlternatives = 1;
        this.listening = true;
        this.speechRecognition.onstart = () => {
          setTimeout(() => {
            console.log("Mic on start");
            
            //this.ngZoneService.run(this.changeUI);
          }, 0);
        }
        this.speechRecognition.onresult = event => {
         
          console.log("on result")
          for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (!event.results[i].isFinal) {
              //this.showInterimResults += ' ' + event.results[i][0].transcript;
              console.log('interim:' + this.showInterimResults + '-----' + event.results[i][0].confidence + '-------- ' + lastConfidence);
              
              if (!this.interimMsg || this.interimMsg.length == 0) {
                this.interimMsg = event.results[i][0].transcript;
              }
              if (event.results[i][0].confidence > 0.05) {
                this.interimMsg = this.capitalize(event.results[i][0].transcript);
                  this.showInterimResults = this.interimMsg;
              }
              lastConfidence = event.results[i][0].confidence;
            } else {
              //if(!this.finalSpeechMessages.includes(event.results[this.finalSpeechMessages.length][0].transcript)){
          

              console.log("final: " + event.results[i][0].transcript + '-----' + event.results[i][0].confidence);
              lastConfidence = 0;
              this.sendListening = true;
              this.emitsendListening.emit(this.sendListening);
              if (event.results[i][0] && event.results[i][0].transcript && event.results[i][0].transcript.trim()) {
                // let message.chatInputBox = event.results[i][0].transcript;
                let tempString = event.results[i][0].transcript;
                this.validate(tempString);
                
              }
              // this.sendMessage.emit(this.capitalize(event.results[i][0].transcript));
              setTimeout(() => {
                // this.listening = false;
                this.sendListening = false;
                this.emitsendListening.emit(this.sendListening);
                this.interimMsg = '';
                this.showInterimResults = '';
                //this.ngZoneService.run(this.changeUI);
              }, 500);
              // }
            }
          }
        }

        this.speechRecognition.onend = (event) => {

          // this.showInterims = false;
          console.log('Speech End');
          //this.sendListening = false;
          setTimeout(() => {

            //this.ngZoneService.run(this.changeUI);
            //this.speechRecognitionEnabled = false;
            if (this.speechRecognitionEnabled && !this.botPause) {
              this.speechRecognition.start();
            }
          }, 0);
          // this.listening = false;
        };
        if (this.speechRecognitionEnabled && !this.botPause) {
          this.speechRecognition.start();
        }
        // this.speechRecognition.start();
      } else if (!this.speechRecognitionEnabled && this.speechRecognition) {
        console.log("stopped");
        // this.listening = false;
        this.speechRecognition.stop();
        // annyang.abort();
      }
      if (this.speechRecognitionEnabled == false) {
        this.speechRecognition.abort();
      }
    }
  }

  capitalize(text: string) {
    return text.charAt(0).toUpperCase() + text.substr(1);
  }

  changeUI() {
  }

  validate(string) {
    let regex = new RegExp(/^\s*\w+([\.-]?\w+)+\s*(([@]+)|([a]+[t]+))+\s*gmail.com+/g);
    if(regex.test(string)) {
      let temp = string.split(' ');
      if(temp[0] == '') {
        temp.shift();
      }
      temp[1] = '@';
      temp = temp.join('');
      this.submit.emit(temp);
    } else {
      this.submit.emit(string);
    }
  }
}
