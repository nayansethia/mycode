import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { UserChatConfig } from '../../../config/app.config';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  audioString: any;
  subscription: Subscription;
  config: UserChatConfig = new UserChatConfig();
  constructor(public router: Router) {

  }

  chatInterpretationMessage;

  ngOnInit() {
    // if(!this.data.getSessionData()){
    //   this.router.navigate(['/user']);
    // }
  }
  logmeout() {
    this.router.navigate(['/app/home']);
  }

  audioOutput(event) {
    console.log("prining event name" + event);
    // this.audioString = event;
  }


  updateChatInterpretation(event) {

    console.log("printing the event " + JSON.stringify(event));
    var dataFromChat = event;

    this.chatInterpretationMessage = event;

    console.log("printing the chatInterpretationMessage" + JSON.stringify(this.chatInterpretationMessage));

  }




}
