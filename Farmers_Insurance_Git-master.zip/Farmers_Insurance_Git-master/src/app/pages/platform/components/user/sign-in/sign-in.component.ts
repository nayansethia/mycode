import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { SocketService } from '../../../services/socket.service';
import { ApiService } from '../../../services/http.service';


@Component({
	selector: 'app-sign-in',
	templateUrl: './sign-in.component.html',
	styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {
	password: string = '';
	username: string = '';
	isSubmiting: boolean = false;
	callForm = false;
	contact: any = '';
	imageSources: Array<string> = [
		'../../../../../../assets/images//carausal1.jpg',
		'../../../../../../assets/images//carausal2.jpg',
		'../../../../../../assets/images//carausal3.jpg'
	]
	constructor(public router: Router, private toastr: ToastrService, public socketService: SocketService, public appservice: ApiService) {
		// this.helperServ.sendUrl('signIn');
	}

	ngOnInit() {
		// this.router.navigate(['/user/dashboard']);
		// this.router.navigate(['/user/dashboard']);
		this.isSubmiting = false;

		document.title = 'Quantiphi Insurance Bot';
	}

	public submit() {
		if (!this.callForm) {
			if (!this.username || !this.password) {
				return this.toastr.error('Please Enter email and phonenumber', '', { timeOut: 1000 });
			}
			// else{
			// 	this.router.navigate(['app/userdashboard']);
			// }
			this.isSubmiting = true;
			this.appservice.loginme(this.username, this.password).subscribe((res: any) => {
				console.log("printing the response " + JSON.stringify(res));
				if (res.status) {
					var userDetail = {
						"userId": res.userId,
						"userSesssion": res.sessionId
					}
					localStorage.setItem("userDetail", JSON.stringify(userDetail));
					localStorage.setItem("previousConv", 'yes');
					this.createSession(this.username)
					// console.log("printing the localstorage details " + localStorage.getItem('userDetail'));
				}
				// if (res.success == true) {
				// 	this.createSession(this.username)
				// } else {
				// 	this.isSubmiting = false;
				// 	return this.toastr.error('Invalid Credentials', '', { timeOut: 1000 });
				// }
			})
		}
	}

	checkForSubmit = (e) => {
		if (e.keyCode == 13 && this.username && this.password) {
			this.submit();
		}
	}
	public callUser(number) {

	}

	public createSession(username) {
		this.appservice.createSession(username).subscribe((res: any) => {
			console.log("printing the session " + JSON.stringify(res));
			localStorage.setItem("sessionId", res.sessionId);
			this.router.navigate(['app/userdashboard']);
			this.isSubmiting = false;
		})
	}
}
