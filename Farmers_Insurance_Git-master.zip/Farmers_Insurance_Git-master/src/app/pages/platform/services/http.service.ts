import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
    providedIn: 'root'
})
export class ApiService {

    constructor(private http: HttpClient) { }

    // URL = "http://localhost:3000/"
    URL = "http://192.168.10.87:3001/"


    public getHeaders() {

        let headers = new HttpHeaders({
            'content-type': 'application/json'
        });
        return { headers: headers };
    }

    loginme(username, password) {
        let data = {
            "username": username,
            "password": password

        }
        return this.http
            .post(this.URL + 'login', data, this.getHeaders())
    }

    createSession(username) {
        let data = {
            "username": username
        }
        return this.http
            .post(this.URL + 'createSession', data, this.getHeaders())
    }

    getPreviousChat(sessionId) {
        let data = {
            "sessionId": sessionId
        }
        return this.http
            .post(this.URL + 'getPreviousChat', data, this.getHeaders())
    }

    getChatHistory(sessionId) {
        let data = {
            "sessionId": sessionId
        }
        return this.http
            .post(this.URL + 'getChatHistory', data, this.getHeaders())
    }

    //   createSession(username:string):any{
    //         let data={
    //         "username":username
    //         }
    //         return this.http
    //         .post(this.baseurl+'createSession',data,this.getHeaders())
    //     }

    //     callUser(contact: number){
    //       let data = {
    //         "number": contact
    //       }
    //       return this.http.post(`${environment.base_url}callBot`,data,this.getHeaders())
    //     }

    //     makeConversation(query:string,participant_name:string){
    //       let data={
    //         "query":query,
    //         "participant_name":participant_name
    //       }

    //       return this.http
    //         .post(this.baseurl +'makeConversation',data,this.getHeaders())
    //     }

    //     joinSession(username:string,session_name:string):any{
    //       let data={
    //         "username":username,
    //         "session_name":session_name
    //       }

    //       return this.http
    //         .post(this.baseurl +'joinSession',data,this.getHeaders())
    //     }

    //     joinCallSession(session_name:string):any{
    //       let data={
    //         "session_name":session_name
    //       }

    //       return this.http
    //         .post(this.baseurl +'joinCallSession',data,this.getHeaders())
    //     }

    //     sendEmail():any{
    //       return this.http
    //       .post(this.baseurl +'sendMail',{},this.getHeaders())
    //     }

    //     getSuggestion(query:string,participantId:string):any{
    //       let data={
    //         "query":query,
    //         "participantId":participantId
    //       }

    //       return this.http
    //         .post(this.baseurl +'getSuggestion',data,this.getHeaders())
    //     }

    //     getAvailableSessions():any{
    //       return this.http
    //         .get(this.baseurl +'session')
    //     }

    //     getDFParameters(){

    //     }

    //     getUserDetails(){

    //     }

}
