import { Injectable, Output, EventEmitter, Input } from '@angular/core';
import { Observable, Observer } from 'rxjs';


@Injectable({
    providedIn: 'root'
})
export class SpeechEventService {
    botTalking = false;

    @Output() change: EventEmitter<boolean> = new EventEmitter();


    set(value) {
        this.botTalking = value;

        this.change.emit(this.botTalking);

    }
}