import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { UserChatConfig, AgentChatConfig, BotConfig } from '../config/app.config';

@Injectable({
  providedIn: 'root'
})

export class HelperService {
    chatConfig = new Subject<UserChatConfig>();
    $chatConfig = this.chatConfig.asObservable();
    agentchatConfig = new Subject<AgentChatConfig>();
    $agentchatConfig = this.agentchatConfig.asObservable();
    url = new Subject();
    $url = this.url.asObservable();
    loader = new Subject();
    $loader = this.loader.asObservable();
    collapseOpen = true;
    sendCollapseFlag = new Subject();
    $sendCollapseFlag = this.sendCollapseFlag.asObservable();
    constructor() {
        // console.log(this.url);
    }

    sendChatConfig(config: UserChatConfig) {
        this.chatConfig.next(config);
    }

    sendAgentChatConfig(config: AgentChatConfig) {
        this.agentchatConfig.next(config);
    }
    sendUrl(url: string) {
        this.url.next(url);
    }
    collapse(collapseOpen) {
        this.collapseOpen = collapseOpen;
        this.sendCollapseFlag.next(this.collapseOpen);
      }
    
      startLoader() {
        this.loader.next(true);
      }
    
      stopLoader() {
        this.loader.next(false);
      }
}