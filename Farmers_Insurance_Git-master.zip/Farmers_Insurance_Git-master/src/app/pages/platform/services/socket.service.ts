import { Injectable } from '@angular/core';
import { Observable, Observer } from 'rxjs';

import * as socketIo from 'socket.io-client';

@Injectable({
    providedIn: 'root'
  })
export class SocketService {
    private socket;

    public initSocket(): void {
        // const SERVER_URL = "http://localhost:3000";
        const SERVER_URL = "http://192.168.10.87:3001";


        if(!this.socket){
            this.socket = socketIo(SERVER_URL);
        }
    }

    public send(_message: Object): void {
        let message = JSON.stringify(_message);
        this.socket.emit('message', message);
    }

    public onEvent(event): Observable<any> {
        return new Observable<any>(observer => {
            this.socket.on(event, (_data: any) => {
                let data = JSON.parse(_data);
                observer.next(data)
            });
            
        });
    }
}