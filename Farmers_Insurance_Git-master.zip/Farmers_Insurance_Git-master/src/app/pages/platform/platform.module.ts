import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlatformPage } from './platform.page';
import { PlatformRouterModule } from './platform.routes';
import { MatToolbarModule, MatButtonModule, MatIconModule, MatSidenavModule, MatDialogModule, MatRadioModule, MatButtonToggleModule, MatFormFieldModule, MatInputModule, MatSlideToggleModule, MatSelectModule, MatTooltipModule, MatTabsModule, MatProgressBarModule, MatStepperModule, MatSortModule } from '@angular/material';
import { SideNavComponent } from './components/side-nav/side-nav.component';
import { HeaderComponent } from '../shared/header/header.component';
import { NoDataFoundComponent } from '../shared/no-data-found/no-data-found.component';
import { TableComponent } from '../shared/table/table.component';
import { ModalComponent } from '../shared/modal/modal.component';
import { PlatformGuard } from './services/platform.guard';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChatboxComponent } from './components/chatbox/chatbox.component';
import { HomeComponent } from './components/home/home.component';
import { ParticlesModule } from 'angular-particle';
import { ModalModule } from 'ngx-bootstrap';
import { UiSwitchModule } from 'ngx-toggle-switch';
import { LoadingBarHttpClientModule } from '@ngx-loading-bar/http-client';
import { NgxGeoautocompleteModule } from 'ngx-geoautocomplete';
import { MatSliderModule } from '@angular/material';
import { NgSelectModule } from '@ng-select/ng-select';
import { ChartsModule } from 'ng2-charts';
import { NgxPaginationModule } from 'ngx-pagination';
import { OwlModule } from 'ngx-owl-carousel';
import { SlideshowModule } from 'ng-simple-slideshow';
import { AccordionModule } from "ngx-accordion";
import { AngularFireAuthModule } from 'angularfire2/auth';
import { AngularFireModule } from 'angularfire2';
import { MomentModule } from 'angular2-moment';
import { PrettyJsonModule } from 'angular2-prettyjson';
import { NgxJsonViewerModule } from 'ngx-json-viewer';
import { MikeComponent } from './components/mike/mike.component';
import { ListeningComponent } from './components/listening/listening.component';
import { MicAnimateComponent } from './components/mic-animate/mic-animate.component';
import { DashboardComponent } from './components/user/dashboard/dashboard.component';
import { SignInComponent } from './components/user/sign-in/sign-in.component';
import { LoaderModule } from './components/loader/loader.module';
import { SuggestionChipComponent } from './components/suggestion-chip/suggestion-chip.component';
import { CarouselComponent } from './components/carousel/carousel.component';
import { OffcanvasComponent } from './components/offcanvas/offcanvas.component';
import { SpeechSynthesisComponent } from './components/speech-synthesis/speech-synthesis.component';
import { AgentSessionScreenComponent } from './components/agent/agent-session-screen/agent-session-screen.component';
import { AgentDashboardComponent } from './components/agent/agent-dashboard/agent-dashboard.component';
import { AgentSignInComponent } from './components/agent/agent-sign-in/agent-sign-in.component';
import { Domsanitizer } from './components/chatbox/domsanitizer.pipe';




@NgModule({
  imports: [
    // BrowserAnimationsModule,
    NgxPaginationModule,
    OwlModule,
    ModalModule,
    UiSwitchModule,
    LoadingBarHttpClientModule,
    SlideshowModule,
    AccordionModule,
    AngularFireAuthModule,
    AngularFireModule,
    MomentModule,
    PrettyJsonModule,
    NgxJsonViewerModule,
    CommonModule,
    FormsModule,
    NgxPaginationModule,
    UiSwitchModule,
    MatSliderModule,
    NgSelectModule,
    ChartsModule,
    OwlModule,
    LoaderModule,
    ModalModule.forRoot(),
    NgxGeoautocompleteModule.forRoot(),
    PrettyJsonModule,
    NgxJsonViewerModule,
    ReactiveFormsModule.withConfig({ warnOnNgModelWithFormControl: 'never' }),

    MatToolbarModule, MatButtonModule, MatIconModule, MatSidenavModule, MatDialogModule,
    MatRadioModule, MatButtonToggleModule, MatFormFieldModule, MatInputModule,
    MatSlideToggleModule, MatSelectModule, MatTooltipModule, MatTabsModule, MatProgressBarModule,
    MatStepperModule, MatSortModule, ParticlesModule, NgxGeoautocompleteModule, MatSliderModule, NgSelectModule, PlatformRouterModule, ChartsModule
  ],
  declarations: [
    PlatformPage, SideNavComponent, DashboardComponent, SignInComponent, Domsanitizer,
    HeaderComponent, NoDataFoundComponent, SuggestionChipComponent, CarouselComponent, OffcanvasComponent, SpeechSynthesisComponent,
    TableComponent, ModalComponent, ChatboxComponent, HomeComponent, MikeComponent, ListeningComponent, MicAnimateComponent,
    AgentSignInComponent, AgentDashboardComponent, AgentSessionScreenComponent
  ],
  entryComponents: [],
  providers: [PlatformGuard, { provide: 'Window', useValue: window }]
})
export class PlatformModule { }
