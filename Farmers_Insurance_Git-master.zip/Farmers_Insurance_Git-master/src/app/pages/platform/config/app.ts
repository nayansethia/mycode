export class UserChatConfig {
    speechSynthesis = true;
    chatParameters = true;
    mike = true;
    feedback = true;
    constructor() {
        this.chatParameters;
        this.mike;
        this.speechSynthesis;
        this.feedback;
    }
}

export class AgentChatConfig {
    userParameters = true;
    suggestion = true;
    mike = true;
    constructor() {
        this.userParameters;
        this.mike;
        this.suggestion;
    }
}

export class BotConfig {
    botname = 'CCAI';
    constructor() {
        this.botname
    }
}