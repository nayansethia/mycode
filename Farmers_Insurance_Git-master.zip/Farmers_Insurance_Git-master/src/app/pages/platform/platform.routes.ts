import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlatformPage } from './platform.page';
import { PlatformGuard } from './services/platform.guard';
import { ChatboxComponent } from './components/chatbox/chatbox.component';
import { HomeComponent } from './components/home/home.component';
import { DashboardComponent } from './components/user/dashboard/dashboard.component';
import { SignInComponent } from './components/user/sign-in/sign-in.component';
import { AgentSignInComponent } from './components/agent/agent-sign-in/agent-sign-in.component';
import { AgentDashboardComponent } from './components/agent/agent-dashboard/agent-dashboard.component';
import { AgentSessionScreenComponent } from './components/agent/agent-session-screen/agent-session-screen.component';
//import { AgentResolverService } from './services/agent-resolver.service';

const routes: Routes = [
    {
        path: '', component: PlatformPage, children: [
            { path: 'home', component: HomeComponent },
            { path: 'bot', component: ChatboxComponent },
            { path: 'usersignin', component: SignInComponent },
            { path: 'userdashboard', component: DashboardComponent },
            { path: 'agent', component: AgentSignInComponent },
            // { path: 'agent/dashboard/:name/:liveAgentMode', component: AgentDashboardComponent, resolve: { session: AgentResolverService } },
            { path: 'agent/sessions', component: AgentSessionScreenComponent },
            { path: 'agentdashboard', component: AgentDashboardComponent },



            {
                path: 'admin', canActivate: [PlatformGuard], children: [
                    { path: '', redirectTo: 'manageusers' }
                ]
            },
            { path: '', redirectTo: 'home' }
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PlatformRouterModule { }