export const Suggestions:any = [
    {
        intentName:"Welcome Intent", 
        props:[
        "Account balance",
        "Reset password",
        "Update my address",
        "Other"
        ]
    },
    {
        intentName:"Default Fallback Intent", 
        props:[
        "Chat",
        "Audio/Voice call",
        "Video call"
        ]
    }
]