// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  //  base_url: "http://localhost:3000/",
  base_url: "https://ccaibanking.q-appliedai.com/",
  firebase: {
    apiKey: "AIzaSyBPK6JiZoxwB2xxra6IheW4Qrc6U2Gz8kw",
    authDomain: "q-conduentcc.firebaseapp.com",
    databaseURL: "https://q-conduentcc.firebaseio.com",
    projectId: "q-conduentcc",
    storageBucket: "",
    messagingSenderId: "961115275702"
  },
  textToSpeechURL: 'https://texttospeech.googleapis.com/v1beta1/text:synthesize?key=',
  getVoiceUrl: 'https://texttospeech.googleapis.com/v1/voices?key=',
  getSessions: 'https://us-central1-q-healthcarecc.cloudfunctions.net/getSessions',
  getSessionById: 'https://us-central1-q-healthcarecc.cloudfunctions.net/sessionById',
  storeSession: 'https://us-central1-q-healthcarecc.cloudfunctions.net/storeSession',
  getAnalytics: 'getAnalytics/',
  storeFeedBackPercentage: 'https://us-central1-q-healthcarecc.cloudfunctions.net/feedbackPercentage',
  getFeedBackPercentage: 'https://us-central1-q-healthcarecc.cloudfunctions.net/getFeedBackPercentage',
  mailer: 'sendMail',
  getLatitudeLongitude: 'https://maps.googleapis.com/maps/api/geocode/json?',
  getAddressFromLatLong: 'https://maps.googleapis.com/maps/api/js?',
  getUserNumber: 'call',
  startVideoCall: 'videoCall'

};

/*
 * In development mode, for easier debugging, you can ignore zone related error
 * stack frames such as `zone.run`/`zoneDelegate.invokeTask` by importing the
 * below file. Don't forget to comment it out in production mode
 * because it will have a performance impact when errors are thrown
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
